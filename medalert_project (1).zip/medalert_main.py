import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse

from app.api.routes import patients, predict, auth
from app.core.config import settings
from app.db.database import engine, Base

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger("medalert")


# ---------------------------------------------------------------------------
# Lifespan — runs once on startup and once on shutdown
# ---------------------------------------------------------------------------
@asynccontextmanager
async def lifespan(app: FastAPI):
    # --- Startup ---
    logger.info("Starting MedAlert API...")

    # Create DB tables if they don't exist (use Alembic in production)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Database connection established.")

    # Load ML model into app state so routes can access it without reloading
    from app.services.prediction_service import load_model
    app.state.model = load_model(settings.MODEL_PATH)
    logger.info(f"ML model loaded from {settings.MODEL_PATH}")

    yield  # Application runs here

    # --- Shutdown ---
    logger.info("Shutting down MedAlert API...")
    await engine.dispose()


# ---------------------------------------------------------------------------
# App instance
# ---------------------------------------------------------------------------
app = FastAPI(
    title="MedAlert API",
    description="AI-powered disease outbreak prediction and early warning system.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)


# ---------------------------------------------------------------------------
# Middleware
# ---------------------------------------------------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,  # e.g. ["http://localhost:5173"]
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(GZipMiddleware, minimum_size=1000)


# ---------------------------------------------------------------------------
# Routers
# ---------------------------------------------------------------------------
app.include_router(auth.router,    prefix="/api/v1/auth",        tags=["Auth"])
app.include_router(patients.router, prefix="/api/v1/patients",   tags=["Patients"])
app.include_router(predict.router,  prefix="/api/v1/predictions", tags=["Predictions"])


# ---------------------------------------------------------------------------
# Core endpoints
# ---------------------------------------------------------------------------
@app.get("/", include_in_schema=False)
async def root():
    return {"message": "MedAlert API is running 🚑", "docs": "/docs"}


@app.get("/api/v1/health", tags=["Health"])
async def health_check():
    """Liveness probe — used by Docker and load balancers."""
    return {
        "status": "ok",
        "version": app.version,
        "model_loaded": hasattr(app.state, "model") and app.state.model is not None,
    }


# ---------------------------------------------------------------------------
# Global exception handler
# ---------------------------------------------------------------------------
@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    logger.exception(f"Unhandled error on {request.url}: {exc}")
    return JSONResponse(
        status_code=500,
        content={"detail": "An internal server error occurred. Please try again later."},
    )
