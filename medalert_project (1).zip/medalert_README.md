# 🚑 MedAlert

> AI-powered disease outbreak prediction and early warning system.

![Python](https://img.shields.io/badge/Python-3.11+-3776AB?style=flat-square&logo=python&logoColor=white)
![FastAPI](https://img.shields.io/badge/FastAPI-0.111-009688?style=flat-square&logo=fastapi&logoColor=white)
![React](https://img.shields.io/badge/React-18-61DAFB?style=flat-square&logo=react&logoColor=black)
![License](https://img.shields.io/badge/License-MIT-green?style=flat-square)
![Status](https://img.shields.io/badge/Status-In%20Development-orange?style=flat-square)

MedAlert uses machine learning to predict disease outbreaks before they escalate — ingesting epidemiological data, weather patterns, and population density signals to surface early warnings via a REST API and interactive dashboard.

---

## ✨ Features

- **Outbreak Prediction** — ML model trained on historical epidemiological data to forecast disease spread risk by region
- **REST API** — FastAPI backend with typed endpoints for submitting patient data and retrieving predictions
- **Risk Scoring** — Per-region risk scores with confidence intervals and contributing factor breakdown
- **Dashboard** *(planned)* — React frontend with live maps, trend charts, and alert management
- **Explainability** — SHAP-based feature importance so clinicians understand *why* a risk score was assigned

---

## 🏗 Architecture

```
ai-disease-prediction/
├── backend/               # FastAPI application
│   ├── app/
│   │   ├── api/routes/    # predict.py, patients.py, auth.py
│   │   ├── services/      # prediction_service.py, patient_service.py
│   │   ├── models/        # SQLAlchemy ORM models
│   │   ├── schemas/       # Pydantic request/response schemas
│   │   ├── core/          # config, security, logging
│   │   └── db/            # database session, migrations
│   ├── main.py
│   └── requirements.txt
├── ml/                    # ML pipeline (independent of API)
│   ├── data/              # raw/, processed/, splits/
│   ├── notebooks/         # eda.ipynb, training.ipynb
│   ├── src/               # train.py, evaluate.py, feature_engineering.py
│   └── saved_models/      # model_v1.pkl + metadata JSON
├── frontend/              # React + Vite (planned)
├── docker-compose.yml
└── Makefile
```

---

## 🚀 Getting Started

### Prerequisites

- Python 3.11+
- PostgreSQL 15+
- Node.js 20+ *(for frontend)*

### 1. Clone the repository

```bash
git clone https://github.com/your-org/medalert.git
cd medalert
```

### 2. Configure environment

```bash
cp .env.example .env
# Edit .env with your database credentials and API keys
```

### 3. Install dependencies

```bash
# Backend
cd backend
pip install -r requirements.txt

# Or use the Makefile shortcut from the root
make install
```

### 4. Set up the database

```bash
make migrate
# or manually:
alembic upgrade head
```

### 5. Run the development server

```bash
uvicorn backend.main:app --reload
# API available at http://localhost:8000
# Docs at http://localhost:8000/docs
```

### Docker (recommended)

```bash
docker compose up --build
```

---

## 📡 API Overview

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/v1/predict` | Submit patient/region data, get risk prediction |
| `GET` | `/api/v1/predictions/{id}` | Retrieve a past prediction by ID |
| `GET` | `/api/v1/patients` | List patients (paginated) |
| `POST` | `/api/v1/patients` | Register a new patient record |
| `GET` | `/api/v1/health` | Health check |

Full interactive docs available at `/docs` (Swagger) and `/redoc` when the server is running.

### Example request

```bash
curl -X POST http://localhost:8000/api/v1/predict \
  -H "Content-Type: application/json" \
  -d '{
    "region": "AP-Nellore",
    "population": 1500000,
    "temperature_c": 34.2,
    "humidity_pct": 78,
    "reported_cases_7d": 42
  }'
```

### Example response

```json
{
  "prediction_id": "pred_01j2x...",
  "region": "AP-Nellore",
  "risk_score": 0.74,
  "risk_level": "HIGH",
  "confidence": 0.89,
  "top_factors": [
    { "feature": "humidity_pct", "contribution": 0.31 },
    { "feature": "reported_cases_7d", "contribution": 0.28 }
  ],
  "predicted_at": "2026-04-05T10:30:00Z"
}
```

---

## 🧠 ML Pipeline

The model is trained separately from the API and the artifact is loaded at server startup.

```bash
# Run EDA notebook
jupyter notebook ml/notebooks/eda.ipynb

# Train the model
python ml/src/train.py --config ml/config.yaml

# Evaluate
python ml/src/evaluate.py --model ml/saved_models/model_v1.pkl
```

Model artifacts are saved to `ml/saved_models/` with a companion `_meta.json` tracking training date, dataset version, and performance metrics. The backend reads the model path from `.env`.

---

## 🧪 Testing

```bash
# Run all tests
make test

# Backend only
cd backend && pytest tests/ -v

# With coverage
pytest tests/ --cov=app --cov-report=html
```

---

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feat/your-feature`
3. Commit your changes: `git commit -m 'feat: add your feature'`
4. Push and open a Pull Request

Please follow [Conventional Commits](https://www.conventionalcommits.org/) for commit messages.

---

## 📋 Roadmap

- [x] FastAPI backend with prediction endpoint
- [x] ML model training pipeline
- [ ] React dashboard with risk maps
- [ ] Real-time alerts via WebSocket
- [ ] Multi-disease model support
- [ ] FHIR-compatible patient data ingestion

---

## 📄 License

MIT © 2026 MedAlert Contributors
